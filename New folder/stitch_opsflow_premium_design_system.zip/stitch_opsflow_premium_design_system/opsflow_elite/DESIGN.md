---
name: OpsFlow Elite
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#444748'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1a1c1a'
  on-tertiary-container: '#848482'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#e3e2e0'
  tertiary-fixed-dim: '#c7c6c4'
  on-tertiary-fixed: '#1a1c1a'
  on-tertiary-fixed-variant: '#464745'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '600'
    lineHeight: '1.3'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-padding: 40px
  gutter: 24px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style

The design system is centered on **Modern Luxury and Quiet Authority**. It targets an executive and high-level operations audience who value clarity, precision, and an environment that feels bespoke rather than mass-produced. 

The aesthetic is a blend of **Minimalism** and **Modern Corporate**, utilizing a high-contrast relationship between the deep, immersive sidebar and the airy, warm workspace. The emotional response should be one of "composed productivity"—where the UI feels like a high-end physical office space. Whitespace is used as a luxury commodity, ensuring no screen feels cluttered or purely utilitarian.

## Colors

This design system utilizes a sophisticated, warm-neutral palette to differentiate between global navigation and focused work areas.

- **Primary & Accent:** Deep Charcoal (#1A1A1A) provides the structural foundation, while Muted Gold (#C5A059) is used sparingly for high-value actions, brand moments, and active indicators to signify premium quality.
- **Surface Strategy:** The main workspace uses a Warm Ivory (#FAF9F6) to reduce eye strain compared to pure white, while interactive Cards use Pure White (#FFFFFF) to "pop" forward in the visual stack.
- **Status Indicators:** Avoid vibrant "neon" alerts. Use the muted, earthy tones (Sage, Dusty Blue, Rust) to convey information without breaking the sophisticated atmosphere.

## Typography

The typographic scale relies on a high-contrast pairing between the serif **Playfair Display** and the sans-serif **Inter**.

- **Editorial Headings:** Use Playfair Display for page titles and section headers. This introduces a literary, authoritative feel to the data. 
- **Functional Clarity:** Inter is reserved for all data-heavy elements, tables, and inputs to ensure maximum legibility at small sizes.
- **Labels:** Use uppercase for `label-lg` with slight letter spacing to denote secondary categorization or table headers, reinforcing the "curated" look.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid** model. The sidebar remains at a fixed width (280px) to maintain its architectural presence, while the main content area fluidly expands with a maximum content width of 1600px to prevent excessive line lengths.

- **Generous Margins:** A standard 40px padding for main containers creates an "airy" feel, separating the app logic from the edges of the browser.
- **Grid:** Use a 12-column grid for dashboard layouts with 24px gutters.
- **Vertical Rhythm:** Elements are spaced in multiples of 8px, but larger jumps (48px+) should be used between unrelated sections to maintain the luxurious sense of space.

## Elevation & Depth

Depth in this design system is achieved through **Tonal Layering** and **Subtle Optics** rather than heavy shadows.

- **The Foundation:** The Warm Ivory background sits at the lowest elevation (Level 0).
- **The Cards:** Pure White cards sit at Level 1. They are defined by a 1px border in `#E5E5E5` and a very soft, diffused shadow: `0 4px 20px rgba(0, 0, 0, 0.03)`.
- **The Interactive:** Floating elements (dropdowns, modals) use a slightly more pronounced shadow and a 1px border in the muted gold or charcoal to indicate focus.
- **Dividers:** Use 1px solid lines in the Neutral color (#E5E5E5) for horizontal separation within cards.

## Shapes

The shape language is refined and consistent, avoiding the extreme "bubbly" look of consumer apps while shunning the harshness of 0px corners.

- **Standard Radius:** 8px (`rounded`) is the default for buttons and input fields.
- **Large Radius:** 12px (`rounded-lg`) is used for main content cards and containers.
- **Contextual Radius:** Status badges and tags use a higher radius (16px+) to create a distinct "pill" shape that contrasts with the more rectangular structural elements.

## Components

- **Buttons:** 
  - *Primary:* Deep Charcoal (#1A1A1A) with Soft Off-White text.
  - *Secondary:* Muted Gold (#C5A059) with White text for key "Call to Action" items.
  - *Tertiary/Ghost:* Transparent background with a thin 1px charcoal border.
- **Input Fields:** Pure white background, 8px radius, 1px `#E5E5E5` border. On focus, the border transitions to Muted Gold.
- **Status Badges:** Use low-saturation backgrounds (e.g., Sage for Active) with a 20% opacity of the same color for the background and 100% opacity for the text.
- **Sidebar Nav:** Items should have a subtle gold vertical bar (2px wide) on the left side to indicate the active state, paired with a soft background highlight in a slightly lighter charcoal.
- **Data Tables:** Remove all vertical borders. Use 1px horizontal dividers. Table headers should use the `label-lg` typography style for a clean, professional look.
- **Cards:** Always include a generous 24px or 32px internal padding to maintain the premium whitespace standard.